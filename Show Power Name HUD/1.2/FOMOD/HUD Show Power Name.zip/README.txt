Adds the selected power name above the health bar

Patches:
- Scanner Encumbrance Display with Time
- Deadly Hazards

Languages:
- English
- Deutsch
- Español
- Français
- Italiano
- 日本語
- Polski
- Português (Brasil)
- 中国人