Adds the selected power name above the health bar

Patches:
- Scanner Encumbrance Display with Time

Languages:
- English
- Deutsch
- Español
- Français
- Italiano
- 日本語
- Polski
- Português (Brasil)
- 中国人