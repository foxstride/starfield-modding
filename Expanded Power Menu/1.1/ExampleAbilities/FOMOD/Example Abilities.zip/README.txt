Additional example files for new powers and custom icons

You will need to add these spells with player.addspell in game

Add ExampleAbilities.esm to Plugins.txt

These spells are not meant for gameplay