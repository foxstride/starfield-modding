-------
Hotkeys For Galaxy Map
-------
1 - Toggle Star Names
2 - Toggle Star Name Colors 
(Not the numpad)